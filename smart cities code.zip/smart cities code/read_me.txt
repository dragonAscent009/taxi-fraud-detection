The CSV files in this folder have only the cleaned data for our choosen S-D pairs. The original data is too big too be submitted as a attachment. Link to the data source can be found in the report.
